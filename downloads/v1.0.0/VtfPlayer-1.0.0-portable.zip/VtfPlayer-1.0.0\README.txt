﻿VtfPlayer 1.0.0 (portable)

Run VtfPlayer.exe. Nothing is installed and nothing is written outside:

  %APPDATA%\VtfPlayer\native\library.db   media library, watch progress,
                                          playlists, settings, thumbnails
  %APPDATA%\VtfPlayer\native\window.txt   window position
  %APPDATA%\VtfPlayer\native\log.txt      log of the last run

To move the whole thing to another machine, copy this folder and that
library.db. Delete library.db to start over.

Open-source components and their licences: see licenses\NOTICE.txt.
This program does not use the network and collects nothing -- see the
privacy note under Settings > About.

Set VTF_DB to point the library somewhere else (used by the test scripts).

Settings are under the O key or the gear in the media library toolbar.
File association is off by default -- turn it on in Settings > Appearance.
